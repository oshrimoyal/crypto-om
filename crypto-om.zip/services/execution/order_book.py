"""
Local order book simulator (placeholder).  In a real implementation this would
track outstanding orders and partial fills.
"""


class OrderBook:
    pass